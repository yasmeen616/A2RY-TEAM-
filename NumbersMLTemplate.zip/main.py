from mlnumbers import classifyNumbers, storeNumbers
from mlmodel import trainModel, checkModel



API_KEY = "ecd27f90-84b4-11eb-84e3-1d2b9cdb1e1e96971854-3b1b-4eee-b425-50bbeb54a210"


# -------------------------------------------------------
# CHECK IF THE MACHINE LEARNING MODEL IS READY TO USE
# -------------------------------------------------------

# you can use this to check if your machine learning model
# has finished training 

status = checkModel(API_KEY)
print (status)




# -------------------------------------------------------
# USE YOUR MACHINE LEARNING MODEL TO RECOGNIZE NUMBERS 
# -------------------------------------------------------

# CHANGE THIS to the data that you want your 
# machine learning model to classify
data1 = "male"
data2 = 0
data3 = 0
data4 = 0
data5 = "yes"
data6 = "yes"
data7 = 0
data8 = 0

test_data = [ data1, data2, data3, data4, data5, data6, data7, data8 ]

demo = classifyNumbers(API_KEY, test_data)

label = demo["class_name"]
confidence = demo["confidence"]

# CHANGE THIS to do something different with the result
print ("result: '%s' with %d%% confidence" % (label, confidence))




# -------------------------------------------------------
# ADD TRAINING EXAMPLES TO YOUR MACHINE LEARNING PROJECT
# -------------------------------------------------------

# CHANGE THIS to the data that you want to add 
# to your project training data
data1 = "male"
data2 = 30
data3 = 2
data4 = 28
data5 = "no"
data6 = "yes"
data7 = 25
data8 = 4

training_data = [ data1, data2, data3, data4, data5, data6, data7, data8 ]

# CHANGE THIS to the training bucket to add the
# training example to
training_label = "safe"

# remove the comment on the next line to use this 
storeNumbers(API_KEY, training_data, training_label)



# -------------------------------------------------------
# TRAIN A NEW MACHINE LEARNING MODEL
# -------------------------------------------------------

# after collecting new training examples, you can use 
# to train a new machine learning model 

# remove the comment on the next line to use this 
# trainModel(API_KEY)
